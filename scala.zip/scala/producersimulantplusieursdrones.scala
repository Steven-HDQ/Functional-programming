import java.util.Properties

import org.apache.kafka.clients.producer._

object producersimulantplusieursdrones {

  def main(args: Array[String]): Unit = {

    writeToKafka("quick-start")

  }

  def writeToKafka(topic: String): Unit = {

    val props = new Properties()

    props.put("bootstrap.servers", "localhost:9092")

    props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer")

    props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer")
    //csv path to be changed
    val bufferedSource = scala.io.Source.fromFile("data_cleaned.csv")
    val producer = new KafkaProducer[String, String](props)
    bufferedSource.getLines.drop(1).foreach { line =>
    var cols = line.split(",").map(_.trim)
    var message = "{ " + "Issue Date : " + "\"" + s"${cols(0)}" + "\""  + ", Violation Time : " + "\"" + s"${cols(1)}" + "\"" +
		         ", Violation Location : "+ "\"" + s"${cols(2)}"+ "\"" + ", PlateId : "+ "\"" + s"${cols(3)}"+ "\"" +
       			 ", ViolationCode : "+ "\"" + s"${cols(4)}" + "\"" + " }"
    val record = new ProducerRecord[String, String](topic, "key", message)
    producer.send(record)
    }
    bufferedSource.close   
    producer.close()

    println("\n Finish sending")
  }

}
